export default function Wallet(){
  return (
    <div style={{padding:24,background:'#0b0b0b',color:'#e6fff1',minHeight:'100vh'}}>
      <h1>Wallet (placeholder)</h1>
      <p>Connect Phantom / MetaMask to manage wallets.</p>
    </div>
  )
}
