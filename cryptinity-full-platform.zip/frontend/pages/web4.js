import Link from 'next/link'
const items = ['Deluxe Casino','E-Remittance','Hybrid Stake','E-Vault','E-Insurance','E-Visa','Affiliate','E-Store','E-Games','Netflix','E-Security','E-Exchange','E-Chain','E-Vip','E-Cashback','E-Sport']
export default function Web4(){
  return (
    <div style={{padding:24,background:'#05070a',color:'#dfffe8',minHeight:'100vh'}}>
      <h1>Web4 Ecosystem — Coming Soon</h1>
      <div style={{display:'grid',gridTemplateColumns:'repeat(auto-fit,minmax(220px,1fr))',gap:12,marginTop:20}}>
        {items.map(it=>(
          <div key={it} style={{background:'#071013',padding:16,borderRadius:12,boxShadow:'0 6px 20px rgba(0,255,150,0.06)'}}>
            <h3 style={{color:'#6fffd6'}}>{it}</h3>
            <p style={{color:'#9fd8c7'}}>Coming soon — join waitlist</p>
          </div>
        ))}
      </div>
      <p style={{marginTop:20}}><Link href='/'><a style={{color:'#6fffd6'}}>Back</a></Link></p>
    </div>
  )
}
