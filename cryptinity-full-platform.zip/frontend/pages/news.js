import Link from 'next/link'
export default function News(){
  return (
    <div style={{padding:24,background:'#f2f5f7',minHeight:'100vh'}}>
      <h1>News Feed (sample)</h1>
      <p>Feed placeholder. This will connect to Firebase posts.</p>
      <ul>
        <li>Post 1: Welcome to Cryptinity</li>
        <li>Post 2: CTY token announced</li>
      </ul>
      <p><Link href='/'><a>Back</a></Link></p>
    </div>
  )
}
