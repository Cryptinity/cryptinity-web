import Link from 'next/link'
export default function Home(){
  return (
    <div style={{background:'#05070a',color:'#e6fff1',minHeight:'100vh',padding:24,fontFamily:'Inter, Arial'}}>
      <header style={{display:'flex',alignItems:'center',justifyContent:'space-between'}}>
        <h1 style={{color:'#6fffd6'}}>Cryptinity</h1>
        <nav>
          <Link href='/news'><a style={{color:'#fff',marginRight:12}}>News Feed</a></Link>
          <Link href='/wallet'><a style={{color:'#fff',marginRight:12}}>Wallet</a></Link>
          <Link href='/web4'><a style={{color:'#fff'}}>Web4 Ecosystem</a></Link>
        </nav>
      </header>
      <main style={{marginTop:40}}>
        <h2>Welcome</h2>
        <p>Cryptinity full platform (frontend placeholder). Use the links above to explore the sample pages.</p>
      </main>
    </div>
  )
}
