// app/(features)/FeedScreen.jsx
import React, { useEffect, useState } from 'react';
import { View, Text, Button, FlatList } from 'react-native';
import { db } from '../services/firebase';
import { collection, query, orderBy, onSnapshot } from 'firebase/firestore';

export default function FeedScreen({ navigation }) {
  const [posts, setPosts] = useState([]);

  useEffect(() => {
    const q = query(collection(db, 'posts'), orderBy('createdAt', 'desc'));
    const unsub = onSnapshot(q, (snap) => {
      setPosts(snap.docs.map(d => ({ id: d.id, ...d.data() })));
    }, (err) => {
      console.log('feed onSnapshot error', err);
    });
    return () => unsub();
  }, []);

  return (
    <View style={{ flex: 1, padding: 16 }}>
      <Button title="Open Chat" onPress={() => navigation.navigate('ChatList')} />
      <FlatList
        data={posts}
        keyExtractor={i => i.id}
        renderItem={({ item }) => (
          <View style={{ padding: 12, backgroundColor: '#fff', marginBottom: 12, borderRadius: 8 }}>
            <Text style={{ fontWeight: '700' }}>{item.authorName || 'User'}</Text>
            <Text>{item.text}</Text>
          </View>
        )}
      />
    </View>
  );
}
