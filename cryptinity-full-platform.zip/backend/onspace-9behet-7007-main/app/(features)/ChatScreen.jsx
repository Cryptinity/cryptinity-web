// app/(features)/ChatScreen.jsx
import React, { useEffect, useState } from 'react';
import { View, Text, TextInput, Button, FlatList } from 'react-native';
import { db } from '../services/firebase';
import { collection, query, orderBy, onSnapshot, addDoc, serverTimestamp } from 'firebase/firestore';
import { auth } from '../services/firebase';

export default function ChatScreen({ route }) {
  const { chatId } = route.params;
  const [messages, setMessages] = useState([]);
  const [text, setText] = useState('');

  useEffect(() => {
    const q = query(collection(db, `chats/${chatId}/messages`), orderBy('createdAt', 'asc'));
    const unsub = onSnapshot(q, snap => setMessages(snap.docs.map(d => ({ id: d.id, ...d.data() }))));
    return () => unsub();
  }, [chatId]);

  const send = async () => {
    if (!text) return;
    await addDoc(collection(db, `chats/${chatId}/messages`), {
      senderId: auth?.currentUser?.uid || 'anon',
      text,
      createdAt: serverTimestamp()
    });
    setText('');
  };

  return (
    <View style={{ flex: 1, padding: 12 }}>
      <FlatList data={messages} keyExtractor={m => m.id} renderItem={({ item }) => (
        <View style={{ padding: 8, marginBottom: 8, backgroundColor: '#fff', borderRadius: 8 }}>
          <Text style={{ fontWeight: '700' }}>{item.senderId}</Text>
          <Text>{item.text}</Text>
        </View>
      )} />
      <View style={{ flexDirection: 'row', gap: 8 }}>
        <TextInput value={text} onChangeText={setText} style={{ flex: 1, padding: 8, backgroundColor: '#fff', borderRadius: 8 }} />
        <Button title="Send" onPress={send} />
      </View>
    </View>
  );
}
