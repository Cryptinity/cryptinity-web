// app/services/cloudinary.js
// Uploads files to Cloudinary using unsigned preset 'cryptinity'
const CLOUD_NAME = 'dpiypv2r5'; // safe public value
const UPLOAD_PRESET = 'cryptinity';

export async function uploadToCloudinary(uri, fileName='upload.jpg') {
  const api = `https://api.cloudinary.com/v1_1/${CLOUD_NAME}/upload`;
  const form = new FormData();
  try {
    const response = await fetch(uri);
    const blob = await response.blob();
    form.append('file', blob, fileName);
  } catch (e) {
    form.append('file', uri);
  }
  form.append('upload_preset', UPLOAD_PRESET);
  form.append('folder', 'cryptinity_media');
  const res = await fetch(api, {
    method: 'POST',
    body: form
  });
  return res.json();
}
