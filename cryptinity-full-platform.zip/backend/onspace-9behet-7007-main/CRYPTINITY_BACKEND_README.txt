Cryptinity backend-ready integration files added.

Files added:
 - app/services/firebase.js  (expects EXPO_PUBLIC_FIREBASE_* env vars)
 - app/services/cloudinary.js (unsigned preset 'cryptinity', cloud name dpiypv2r5)
 - app/(features)/FeedScreen.jsx
 - app/(features)/ChatList.jsx
 - app/(features)/ChatScreen.jsx

How to configure:
 1) Set the following public env vars via app.json or EAS/Expo secrets:
    EXPO_PUBLIC_FIREBASE_API_KEY (secret, add via EAS or .env locally)
    EXPO_PUBLIC_FIREBASE_AUTH_DOMAIN=cryptinity--ultra--web4.firebaseapp.com
    EXPO_PUBLIC_FIREBASE_PROJECT_ID=cryptinity--ultra--web4
    EXPO_PUBLIC_FIREBASE_STORAGE_BUCKET=cryptinity--ultra--web4.firebasestorage.app
    EXPO_PUBLIC_FIREBASE_MESSAGING_SENDER_ID=624069180316
    EXPO_PUBLIC_FIREBASE_APP_ID=1:624069180316:web:124ddb51d9194fe539a659

 2) For Cloudinary uploads no secret is required for unsigned presets:
    CLOUDINARY_CLOUD_NAME=dpiypv2r5
    UPLOAD_PRESET=cryptinity

 3) Install firebase in project:
    npm install firebase

 4) Run Expo:
    npx expo start -c

Notes:
 - Do NOT commit secret API keys to git.
 - Use Expo secrets or EAS for secure CI builds.
